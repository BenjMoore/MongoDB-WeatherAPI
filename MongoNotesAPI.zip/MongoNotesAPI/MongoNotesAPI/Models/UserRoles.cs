﻿namespace MongoNotesAPI.Models
{
    public enum UserRoles
    {
        TEACHER = 0,
        USER = 100,
        SENSOR = 200,
            
    }
}
